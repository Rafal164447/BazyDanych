# sequences
s = """To Jest Jakis Dlugi tekst an"""
print(s.count('e'))
print(s.count('an'))
print(s.replace('a', '0'))
print(s.upper())
print(s.swapcase())
print(s[4])
print(s[4:10])
print('d' in s)
print('e' in s)
# lists
a = []
a.append('dog')
a.append('cat')
a.append('mouse')
print(a)
print(a[0])
print(a[1])
print(a[-1])
print(a[-2])
b = ['dog', 'cat', 'mouse', [1, 10, 100, 1000]]
print(b[0])
print(b[3])
print(b[3][0])
print(b[3][1])
print(max(b[3]))
print(min(b[3]))

