# Słowniki
d = {}  # pusty słownik
d['todey'] = '22 deg c'
d['yesterday'] = '19 deg c'
print(d)
print(d.keys())
print(d['todey'])
# przykład
order = {}
order['Peter'] = 'Pint of bitter'
order['Paul'] = 'Half pint of Hoegarden'
order['Mary'] = 'Gin Tonic'

for person in order.keys():
    print("{} request {}".format(person, order[person]))

for person in order:  # nie trzeba pisac order.keys() bo domyslnie bierze klucze
    print(person, "request", order[person])

