# loops
def skip13(a, b):
    l = []
    for k in range(a, b):
        if k == 13:
            pass
        else:
            l.append(k)
    return l


def range_double(x):
    l = []
    for i in range(x):
        l.append(2*i)
    return l


print(range_double(4))

animals = ['dog', 'cat', 'mouse']

for animal in animals:
    print('This is the {}'.format(animal))  # {} oznacza puste miesjce .fromat wstawie w puste miejsce zmienna

for i in [0, 1, 2, 3, 4, 5]:
    print('the square of {} is {}'.format(i, i ** 2))

for i in range(6):
    print('the square of {} is {}'.format(i, i ** 2))

print(list(range(1, 10, 2)))

for letter in "Hello world":
    print(letter)
