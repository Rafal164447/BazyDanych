import modul


def area(a, b=1):
    return a*b


def f(a, b, c):
    print("a = {}, b = {}, c = {}".format(a, b, c))


def ff():
    # x = "local"
    print(x)


x = "global"


def testglobal():
    global x
    print(x)
    x = "local"
    print(x)


ff()
print(x)
print("the area is {}".format(area(3)))
print("the area is {}".format(area(2.5, 2)))
print("the area is {}".format(area(2.5)))
print("the area is {}".format(area(3, 3)))
f(1, 2, 3)
f(c=3, a=1, b=2)
f(1, c=3, b=2)
testglobal()
