def sum(xs):  # funkcja z elementem ubocznym
    s = 0
    for i in range(len(xs)):
        s = s + xs.pop()
    return s


# def sum(ds): dobre rozwiazanie
# d = 0
# for elem in ds:
#  d = d + elem
# return d


xs = [10, 20, 30]
print("xs {}; ".format(xs), end='')
print("xs {}; ".format(sum(xs)), end='')
print("xs {}; ".format(xs))

x = 64
while x > 10:
    x = x // 2
    print(x)

eps = 1.0
while eps + 1 > 1:
    eps = eps / 2.0
print("epsilon is {}".format(eps))
