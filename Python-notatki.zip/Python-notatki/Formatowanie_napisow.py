import math
import datetime
p = math.pi

# stara wersja
print("%f" % p)
print("%d" % p)
print("%e" % p)
print("%g" % p)
print("%10s" % "apple")
print("%3s" % "apple")

# nowa wersja
print("{} needs {} pints".format("Peter", 4))
print("{0} needs {1} pints".format("Peter", 4))
print("{1} needs {0} pints".format("Peter", 4))
print("{name} needs {number} pints".format(name="Peter", number=4))
# nowa wersja
a = "abc"
napis = f"a to {a}"
print(napis)
b = 4.2
c = 5
str2 = f"{b} + {c} = {b+c}"
print(str2)
b = 4.2
c = 5
str2 = f"{b:f} + {c:d} = {b+c:e}"
print(str2)


t = datetime.datetime.now()
print(t)
print(str(t))
print(repr(t))

x = 1
print(eval("x + 1"))
s = "[10, 20, 30]"
print(type(s))
print(eval(s))
print(type(eval(s)))
