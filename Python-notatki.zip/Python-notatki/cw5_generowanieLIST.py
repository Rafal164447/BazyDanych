import math
print([2 ** i for i in range(10)])
print([x ** 2 for x in range(10)])
# mozna dodatkowe warunki
print([x for x in range(10) if x > 5])
# wykorzystywanie innych list
xs = [i for i in range(10)]
print(xs)
ys = [x ** 2 for x in xs]
print(ys)
# z biblioteka math
xs = [0.1 * i for i in range(5)]
ys = [math.exp(x) for x in xs]
print(xs)
print(ys)
# przetwarzanie tekstu
words = 'The quick brown fox jumps over the lazy dog'.split()
print(words)

stuff = [[w.upper(), w.lower(), len(w)] for w in words]
for i in stuff:
    print(i)
# coletion.counter() do sprawdzenia

print([i for i in range(10) if i ** 2 > 5])