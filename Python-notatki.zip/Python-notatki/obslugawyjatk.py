# f = open('test.txt', 'r')
# lines = f.readline()
# f.close()
# a = lines.split()
# print(lines.split())
# print(int(a[0]))

f = open("test.txt", "r")
lines = f.readlines()
f.close()

fout = open("odp.txt", "w")
for line in lines:
    suma = 0
    numbers = line.split()
    for i in numbers:
        try:
            suma += int(i)
        except ValueError:
            suma += 0
    fout.write("{} to suma = {}\n".format(" ".join(numbers), suma))
fout.close()
