q = []


# FIFO
def add(n):
    q.insert(0, n)  # moze byc .append


def next():
    return q.pop()


# drugi sposob tmp = q[0] q = q[1:] return tmp
def show():
    print(q)


def length():
    return len(q)
#  FILO


add('asdd')
add('sdas')
next()
show()
