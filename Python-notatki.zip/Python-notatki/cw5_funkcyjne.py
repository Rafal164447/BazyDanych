import math
def f(x):
    return x ** 2


def len_gr_4(s):
    return len(s) > 4


def is_positive(n):
    return n > 0


# funkcja map
print(map(f, [0, 1, 2, 3, 4]))
print(list(map(f, [0, 1, 2, 3, 4])))
print(list(map(math.exp, [0, 0.1, 1.])))

news = 'Python programming occasionally ' \
       'more fun than expected'
slug = "-".join(map(
    lambda w: w[0:6], news.split()))
print(slug)
# przy uzyciu generatora list
slug = "-".join([w[0:6] for w in news.split()])

# funkcja filter
c = 'The quick brown fox jumps'.split()
print(c)
print(list(map(len_gr_4, c)))
print(filter(len_gr_4, c))
print(list(filter(is_positive, [-3, 2, 1, 3, -10])))
print(list(filter(lambda n: n > 0, [-3, 2, 1, 3, -10])))
print([x for x in [-3, 2, 1, 3, -10] if x > 0])
