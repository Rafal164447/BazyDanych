import math


def print_f_table(f):
    for i in range(6):
        x = i * 0.5
        print("{} {}".format(x, f(x)))


def fun(x):
    return x ** 2


funcs = (math.sin, math.cos)
for f in funcs:
    for x in [0, math.pi/2]:
        print("{}({:.3f}) = {:.3f}".format(f.__name__, x, f(x)))

print_f_table(fun)
