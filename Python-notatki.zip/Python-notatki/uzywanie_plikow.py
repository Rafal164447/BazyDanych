# f = open('test.txt', 'w')
# f.write("first line \nsecond line")
# f.close()

# f = open('test.txt', 'r')
# lines = f.readlines()
# f.close()
# print(lines)

# f = open('test.txt', 'r')
# data = f.read()
# f.close()
# print(data)

# f = open('test.txt', 'r')
# for line in f:
#  print(line, end='')
# f.close()

# najlepiej uzywac tego jak wyjdziemy z kontekstu to plik sam sie zamknie
with open('test.txt', 'r') as f:
    data = f.read()
    print(data)

# napisy
c = 'To moj napis'
print(c.split())
print(c.split('o'))
