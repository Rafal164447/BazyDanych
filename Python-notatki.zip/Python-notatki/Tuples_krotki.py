# Tuples - krotki
# w funkcji wypisywanie wiecej niz jednej wartosci dzieki krotce
def f(x):
    return x**2, x**3


t = (3, 4, 50)
a = 10, 5, 21  # to jest jest krotka lepiej z nawiasami
print(t)
print(type(a))
print(t[1])
print(t[:-1])
# mozna zapisaywac hurtowo zmienne
x, y, z = 0, 0, 1
# mozna tez zamieniac wartosci zmiennych
a = 1
b = 2
a, b = b, a
print(a,' ',b)
print('funkcja od x', f(2))
s = 'hello'
# s[4] = 'a'
s = s[0:3] + 'x' + s[4:]
print(s)
# konwersja krotki na liste i odwrotnie
print(tuple([1, 4, 'dog']))
print(list((1, 4, 'dog')))
# mozemy funkcje range zrobic liste lub krotke
print(list(range(5)))
