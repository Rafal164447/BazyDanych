import sys
try:
    f = open('plik.txt', 'r')
except FileNotFoundError:
    print("nie ma takiego pliku")
    sys.exit()
for line in f:
    print(line, end='')
f.close()
