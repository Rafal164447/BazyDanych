def factorial(n):
    if n == 0:
        return 1
    else:
        return n * factorial(n - 1)


def f(n):
    if n == 1:
        return 0
    elif n == 2:
        return 1
    else:
        return f(n-2) + f(n-1)


print(factorial(4))
print(f(30))
