import math
from functools import reduce
def f(x, y):
    print("Called with x={}, y={}".format(x, y))
    return x + y


# memoryzacja
def make_add42():
    def add42(x):
        return x + 42
    return add42

# memoryzacja
def make_adder(y):
    def adder(x):
        return x + y
    return adder

print(reduce(f, [1, 3, 5], 0))
print(reduce(lambda x, y: x * y, [1, 3, 5], 0))
print(reduce(lambda x, y: x * y, [1, 3, 5], 1))

# memoryzacja
add42 = make_add42()
addpi = make_adder(math.pi)
print(add42(2))
print(addpi(-3))
